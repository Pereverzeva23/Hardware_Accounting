﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Учет_аппаратных_средств
{
    public class Core
    {
        public static ApparatureEntities DB = new ApparatureEntities();

        public static User user = new User();
    }
}
